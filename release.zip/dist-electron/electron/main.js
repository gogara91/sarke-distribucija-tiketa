"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const electron_1 = require("electron");
const node_path_1 = __importDefault(require("node:path"));
const isDev = !!process.env.VITE_DEV_SERVER_URL;
const createWindow = async () => {
    const win = new electron_1.BrowserWindow({
        width: 1440,
        height: 960,
        minWidth: 1200,
        minHeight: 800,
        webPreferences: {
            preload: node_path_1.default.join(__dirname, "preload.js"),
            contextIsolation: true,
            nodeIntegration: false
        }
    });
    if (isDev && process.env.VITE_DEV_SERVER_URL) {
        await win.loadURL(process.env.VITE_DEV_SERVER_URL);
        win.webContents.openDevTools({ mode: "detach" });
        return;
    }
    await win.loadFile(node_path_1.default.join(__dirname, "../dist/index.html"));
};
electron_1.app.whenReady().then(() => {
    createWindow().catch((error) => {
        console.error("Failed to create window:", error);
    });
    electron_1.app.on("activate", () => {
        if (electron_1.BrowserWindow.getAllWindows().length === 0) {
            createWindow().catch((error) => {
                console.error("Failed to create window:", error);
            });
        }
    });
});
electron_1.app.on("window-all-closed", () => {
    if (process.platform !== "darwin") {
        electron_1.app.quit();
    }
});
